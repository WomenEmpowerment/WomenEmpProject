package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "NGO_WE")
public class NGOReg {

	@Id
	@GeneratedValue
	@Column(name = "NGO_ID")
	private int ngoId;

	@Column(name = "NAME")
	private String ngoName;

	@Column(name = "CITY")
	private String ngoCity;

	@Column(name = "EMAIL")
	private String ngoEmail;

	@Column(name = "PHNO_NGO")
	private long ngoPhone;

	@Column(name = "ADDRESS")
	private String ngoAdd;
	
	@Column(name = "PASSWORD")
	private String password;
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getNgoId() {
		return ngoId;
	}

	public String getNgoName() {
		return ngoName;
	}

	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}

	public String getNgoCity() {
		return ngoCity;
	}

	public void setNgoCity(String ngoCity) {
		this.ngoCity = ngoCity;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}

	public long getNgoPhone() {
		return ngoPhone;
	}

	public void setNgoPhone(long ngoPhone) {
		this.ngoPhone = ngoPhone;
	}

	public String getNgoAdd() {
		return ngoAdd;
	}

	public void setNgoAdd(String ngoAdd) {
		this.ngoAdd = ngoAdd;
	}

}
