package com.lti.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "ADD_ENROLLMENT_ACCOMODATION")
public class AddEnrollmentAcc {
	
	@Id
	@GeneratedValue
	@Column(name = "ACC_ENROLLMENT_ID")
	private int accEnrollId;
	
	@Column(name = "NGO_ACC_ID")
	private int ngoAccId ;
	
	@Column(name = "NGO_ROOM_AVAIL")
	private String ngoRoomAvail;
	
	@Column(name = "NGO_CITY")
	private String ngoAccCity;

	@Column(name = "NGO_NAME")
	private String ngoName;
	
	@Column(name = "NGO_EMAIL")
	private String ngoEmail;
	
	@Column(name = "NGO_PHONENO")
	private long ngoP;	
	
	@Column(name = "NGO_ADDRESS")
	private String ngoA;

	public int getAccEnrollId() {
		return accEnrollId;
	}

	public void setAccEnrollId(int accEnrollId) {
		this.accEnrollId = accEnrollId;
	}

	public int getNgoAccId() {
		return ngoAccId;
	}

	public void setNgoAccId(int ngoAccId) {
		this.ngoAccId = ngoAccId;
	}

	public String getNgoRoomAvail() {
		return ngoRoomAvail;
	}

	public void setNgoRoomAvail(String ngoRoomAvail) {
		this.ngoRoomAvail = ngoRoomAvail;
	}

	public String getNgoAccCity() {
		return ngoAccCity;
	}

	public void setNgoAccCity(String ngoAccCity) {
		this.ngoAccCity = ngoAccCity;
	}

	public String getNgoName() {
		return ngoName;
	}

	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}

	public long getNgoP() {
		return ngoP;
	}

	public void setNgoP(long ngoP) {
		this.ngoP = ngoP;
	}

	public String getNgoA() {
		return ngoA;
	}

	public void setNgoA(String ngoA) {
		this.ngoA = ngoA;
	} 	
		
	
	

}
