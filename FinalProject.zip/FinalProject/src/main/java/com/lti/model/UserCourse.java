package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "USER_COURSE")
public class UserCourse {

	@Id
	@GeneratedValue
	@Column(name = "UC_ID")
	private int accid;

	@Column(name = "COURSE1")
	private String course1;

	@Column(name = "COURSE2")
	private String course2;

	@Column(name = "COURSE3")
	private String course3;

	public int getAccid() {
		return accid;
	}

	public String getCourse1() {
		return course1;
	}

	public void setCourse1(String course1) {
		this.course1 = course1;
	}

	public String getCourse2() {
		return course2;
	}

	public void setCourse2(String course2) {
		this.course2 = course2;
	}

	public String getCourse3() {
		return course3;
	}

	public void setCourse3(String course3) {
		this.course3 = course3;
	}

	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}

	@OneToOne
	@JoinColumn(name = "ID")
	private Registration registration;

}
