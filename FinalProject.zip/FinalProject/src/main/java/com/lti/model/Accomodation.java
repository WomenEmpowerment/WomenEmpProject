package com.lti.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "WOMEN_ACC")
public class Accomodation {

	@Id
	@GeneratedValue
	@Column(name = "ACC_ID")
	private int accid;

	@Column(name = "CITY")
	private String city;

	// @DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name = "START_DATE")
	private LocalDate startDate;

	// @DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name = "END_DATE")
	private LocalDate endDate;

	@Column(name = "DAYCARE")
	private String dayCare;

	@OneToOne
	@JoinColumn(name = "ID")
	private Registration registration;

	public int getAccid() {
		return accid;
	}

	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	
		public void setStartDate(String startDate) {
		//DateTimeFormatter df= DateTimeFormatter.ofPattern("dd-MON-yyyy");
		//this.startDate = LocalDate.parse(startDate,df);
			this.startDate = LocalDate.parse(startDate);
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		//DateTimeFormatter df= DateTimeFormatter.ofPattern("yyyy-MM-dd");
		//this.endDate = LocalDate.parse(endDate,df);
			this.endDate =  LocalDate.parse(endDate);
	}

	public String getDayCare() {
		return dayCare;
	}

	public void setDayCare(String dayCare) {
		this.dayCare = dayCare;
	}

	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}

}