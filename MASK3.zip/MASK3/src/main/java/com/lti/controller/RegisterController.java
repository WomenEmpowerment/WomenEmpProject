package com.lti.controller;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.model.Login;
import com.lti.model.register;
import com.lti.service.RegisterService;

@Controller
@SessionAttributes("user")
public class RegisterController {

	@Autowired
	private RegisterService regservice;
	
	@RequestMapping(path = "register.lti", method = RequestMethod.POST)
	public String register(register registration)
	{

		
		regservice.registerAdd(registration);
		
		return "Login.jsp";
}

	@RequestMapping(path = "login.lti", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password,ModelMap model) {

		try{
			register login=regservice.checkLogin(username, password);
			//session.setAttribute("login",registeration);
			
			
			model.put("user",login);
			System.out.println("okkk");
			return "Confirm.jsp";
			
		}
		
catch(Exception e){
	System.out.println("not okk");
	model.put("message","invalid username/password");
	return "Login.jsp";
}
	
	
}
}
